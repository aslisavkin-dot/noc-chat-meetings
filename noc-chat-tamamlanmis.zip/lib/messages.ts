import { drizzle } from 'drizzle-orm/node-postgres'
import { pgTable, text, uuid, timestamp, pgSchema, boolean } from 'drizzle-orm/pg-core'
import { Pool } from 'pg'

export const db = drizzle(new Pool({ connectionString: process.env.DATABASE_URL, max: 3, connectionTimeoutMillis: 6000 }))

export const messages = pgTable('noc_messages', {
  id: uuid().defaultRandom().primaryKey(),
  userId: text().notNull(),
  recipientId: text().notNull(),
  body: text().notNull(),
  createdAt: timestamp({ withTimezone: true }).notNull().defaultNow(),
})

export const profiles = pgTable('noc_profiles', {
  userId: text().primaryKey(),
  nickname: text().notNull().unique(),
  updatedAt: timestamp({ withTimezone: true }).notNull().defaultNow(),
})

export const contacts = pgTable('noc_contacts', {
  id: uuid().defaultRandom().primaryKey(),
  userId: text().notNull(),
  contactUserId: text().notNull(),
  createdAt: timestamp({ withTimezone: true }).notNull().defaultNow(),
})

export const meetings = pgTable('noc_meetings', {
  id: uuid().defaultRandom().primaryKey(),
  roomCode: text().notNull().unique(),
  title: text().notNull(),
  hostId: text().notNull(),
  active: boolean().notNull().default(true),
  createdAt: timestamp({ withTimezone: true }).notNull().defaultNow(),
})

export const people = pgSchema('neon_auth').table('user', {
  id: uuid().primaryKey(),
  email: text().notNull(),
  name: text().notNull(),
})

let initialized: Promise<void> | null = null

export async function ensureTables() {
  if (!initialized) {
    initialized = (async () => {
      await db.execute(`
        CREATE TABLE IF NOT EXISTS noc_messages (
          id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
          "userId" text NOT NULL,
          "recipientId" text NOT NULL,
          body text NOT NULL,
          "createdAt" timestamptz NOT NULL DEFAULT now()
        );
        CREATE TABLE IF NOT EXISTS noc_profiles (
          "userId" text PRIMARY KEY,
          nickname text NOT NULL UNIQUE,
          "updatedAt" timestamptz NOT NULL DEFAULT now()
        );
        CREATE TABLE IF NOT EXISTS noc_contacts (
          id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
          "userId" text NOT NULL,
          "contactUserId" text NOT NULL,
          "createdAt" timestamptz NOT NULL DEFAULT now(),
          UNIQUE("userId", "contactUserId")
        );
        CREATE TABLE IF NOT EXISTS noc_meetings (
          id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
          "roomCode" text NOT NULL UNIQUE,
          title text NOT NULL,
          "hostId" text NOT NULL,
          active boolean NOT NULL DEFAULT true,
          "createdAt" timestamptz NOT NULL DEFAULT now()
        );
      `)
    })().catch((err) => {
      initialized = null
      throw err
    })
  }
  return initialized
}
