'use client'
import { createAuthClient } from '@neondatabase/auth/next'
export const client=createAuthClient()
export async function googleLogin(){const {error}=await client.signIn.social({provider:'google',callbackURL:location.origin+'/sohbet',errorCallbackURL:location.origin+'/?giris=hata'});if(error)throw new Error('Google girişine ulaşılamadı.')}
