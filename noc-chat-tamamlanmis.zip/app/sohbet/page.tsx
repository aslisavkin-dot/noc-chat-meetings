import { eq } from 'drizzle-orm'
import { auth } from '@/lib/auth'
import { db, ensureTables, profiles } from '@/lib/messages'
import { redirect } from 'next/navigation'
import { ChatRoom } from '@/components/chat-room'

export const dynamic = 'force-dynamic'

export default async function Page() {
  const session = (await auth.getSession()).data
  if (!session?.user) redirect('/')

  await ensureTables()
  const [profile] = await db
    .select({ nickname: profiles.nickname })
    .from(profiles)
    .where(eq(profiles.userId, session.user.id))
    .limit(1)

  return (
    <ChatRoom
      accountName={session.user.name}
      initialNickname={profile?.nickname ?? null}
    />
  )
}
