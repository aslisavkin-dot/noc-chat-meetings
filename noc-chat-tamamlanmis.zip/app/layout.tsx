import type { Metadata, Viewport } from 'next'
import './globals.css'
export const metadata: Metadata = { title: 'NOC Chat | Bağlantıda kal.', description: 'NOC Chat ile sohbeti, sesli aramayı ve toplantıları keşfet.', icons: { icon: '/noc.svg' } }
export const viewport: Viewport = { themeColor: '#151329', colorScheme: 'dark' }
export default function Layout({children}: Readonly<{children: React.ReactNode}>) { return <html lang="tr"><body>{children}</body></html> }
