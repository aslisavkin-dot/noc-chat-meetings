import { desc, eq } from 'drizzle-orm'
import { auth } from '@/lib/auth'
import { db, ensureTables, meetings, profiles } from '@/lib/messages'

const reply = (data: unknown, status = 200) =>
  Response.json(data, { status, headers: { 'Cache-Control': 'private, no-store' } })

export async function GET() {
  const id = (await auth.getSession()).data?.user?.id
  if (!id) return reply({ error: 'Oturum açmalısın.' }, 401)
  await ensureTables()

  const rows = await db
    .select({
      id: meetings.id,
      roomCode: meetings.roomCode,
      title: meetings.title,
      hostId: meetings.hostId,
      hostNickname: profiles.nickname,
      createdAt: meetings.createdAt,
    })
    .from(meetings)
    .leftJoin(profiles, eq(meetings.hostId, profiles.userId))
    .where(eq(meetings.active, true))
    .orderBy(desc(meetings.createdAt))
    .limit(20)

  return reply(rows)
}

export async function POST(req: Request) {
  if (!req.headers.get('content-type')?.startsWith('application/json'))
    return reply({ error: 'Geçersiz istek.' }, 415)
  const id = (await auth.getSession()).data?.user?.id
  if (!id) return reply({ error: 'Oturum açmalısın.' }, 401)

  const input = await req.json().catch(() => null)
  const title = typeof input?.title === 'string' ? input.title.trim() : ''
  if (!title || title.length > 80) {
    return reply({ error: 'Toplantı başlığı 1-80 karakter arasında olmalı.' }, 400)
  }

  await ensureTables()
  const roomCode = `NOC-Toplanti-${crypto.randomUUID()}`

  const [created] = await db
    .insert(meetings)
    .values({ roomCode, title, hostId: id, active: true })
    .returning()

  return reply({ ok: true, meeting: created }, 201)
}
