import { eq, sql } from 'drizzle-orm'
import { auth } from '@/lib/auth'
import { db, ensureTables, profiles } from '@/lib/messages'

const reply = (data: unknown, status = 200) =>
  Response.json(data, { status, headers: { 'Cache-Control': 'private, no-store' } })

const nickPattern = /^[a-zA-Z0-9_çğıöşüÇĞİÖŞÜ]{3,24}$/

export async function GET() {
  const session = (await auth.getSession()).data
  const id = session?.user?.id
  if (!id) return reply({ error: 'Oturum açmalısın.' }, 401)
  await ensureTables()
  const [row] = await db.select().from(profiles).where(eq(profiles.userId, id)).limit(1)
  return reply({ nickname: row?.nickname ?? null })
}

export async function POST(req: Request) {
  if (!req.headers.get('content-type')?.startsWith('application/json'))
    return reply({ error: 'Geçersiz istek.' }, 415)
  const session = (await auth.getSession()).data
  const id = session?.user?.id
  if (!id) return reply({ error: 'Oturum açmalısın.' }, 401)

  const input = await req.json().catch(() => null)
  const raw = typeof input?.nickname === 'string' ? input.nickname.trim() : ''
  const cleaned = raw.startsWith('@') ? raw.slice(1) : raw

  if (!nickPattern.test(cleaned)) {
    return reply(
      { error: 'Takma ad 3-24 karakter olmalı ve yalnızca harf, rakam veya alt çizgi (_) içermelidir.' },
      400
    )
  }

  await ensureTables()

  const [existing] = await db
    .select({ userId: profiles.userId })
    .from(profiles)
    .where(sql`lower(${profiles.nickname}) = lower(${cleaned}) AND ${profiles.userId} <> ${id}`)
    .limit(1)

  if (existing) {
    return reply({ error: 'Bu takma ad başka bir kullanıcı tarafından alınmış.' }, 409)
  }

  await db
    .insert(profiles)
    .values({ userId: id, nickname: cleaned, updatedAt: new Date() })
    .onConflictDoUpdate({
      target: profiles.userId,
      set: { nickname: cleaned, updatedAt: new Date() },
    })

  return reply({ ok: true, nickname: cleaned }, 200)
}
