import { and, desc, eq, or, sql } from 'drizzle-orm'
import { auth } from '@/lib/auth'
import { contacts, db, ensureTables, messages, people, profiles } from '@/lib/messages'

const reply = (data: unknown, status = 200) =>
  Response.json(data, { status, headers: { 'Cache-Control': 'private, no-store' } })

export async function GET() {
  const id = (await auth.getSession()).data?.user?.id
  if (!id) return reply({ error: 'Oturum açmalısın.' }, 401)
  await ensureTables()

  const savedRows = await db
    .select({
      userId: profiles.userId,
      nickname: profiles.nickname,
      fullName: people.name,
    })
    .from(contacts)
    .innerJoin(profiles, eq(contacts.contactUserId, profiles.userId))
    .leftJoin(people, eq(sql`${people.id}::text`, profiles.userId))
    .where(eq(contacts.userId, id))
    .orderBy(desc(contacts.createdAt))

  // Also include anyone we've exchanged messages with so incoming messages appear automatically
  const msgUsers = await db
    .select({
      otherId: sql<string>`case when ${messages.userId} = ${id} then ${messages.recipientId} else ${messages.userId} end`,
    })
    .from(messages)
    .where(or(eq(messages.userId, id), eq(messages.recipientId, id)))
    .groupBy(sql`case when ${messages.userId} = ${id} then ${messages.recipientId} else ${messages.userId} end`)

  const knownIds = new Set(savedRows.map((r) => r.userId))
  const extraIds = msgUsers.map((m) => m.otherId).filter((uid) => !knownIds.has(uid))

  let extraRows: { userId: string; nickname: string; fullName: string | null }[] = []
  if (extraIds.length > 0) {
    extraRows = await db
      .select({
        userId: profiles.userId,
        nickname: profiles.nickname,
        fullName: people.name,
      })
      .from(profiles)
      .leftJoin(people, eq(sql`${people.id}::text`, profiles.userId))
      .where(sql`${profiles.userId} IN (${sql.join(extraIds.map((x) => sql`${x}`), sql`, `)})`)
  }

  return reply([...savedRows, ...extraRows])
}

export async function POST(req: Request) {
  if (!req.headers.get('content-type')?.startsWith('application/json'))
    return reply({ error: 'Geçersiz istek.' }, 415)
  const id = (await auth.getSession()).data?.user?.id
  if (!id) return reply({ error: 'Oturum açmalısın.' }, 401)

  const input = await req.json().catch(() => null)
  const raw = typeof input?.nickname === 'string' ? input.nickname.trim() : ''
  const cleaned = raw.startsWith('@') ? raw.slice(1) : raw

  if (!cleaned) {
    return reply({ error: 'Eklemek istediğin kişinin takma adını yaz.' }, 400)
  }

  await ensureTables()

  const [target] = await db
    .select({
      userId: profiles.userId,
      nickname: profiles.nickname,
      fullName: people.name,
    })
    .from(profiles)
    .leftJoin(people, eq(sql`${people.id}::text`, profiles.userId))
    .where(sql`lower(${profiles.nickname}) = lower(${cleaned})`)
    .limit(1)

  if (!target) {
    return reply({ error: `"${cleaned}" takma adına sahip kullanıcı bulunamadı. Sunucuya girip takma ad oluşturmuş olmalı.` }, 404)
  }

  if (target.userId === id) {
    return reply({ error: 'Kendini kişi listesine ekleyemezsin.' }, 400)
  }

  await db
    .insert(contacts)
    .values({ userId: id, contactUserId: target.userId })
    .onConflictDoNothing()

  return reply({ ok: true, contact: target }, 201)
}
