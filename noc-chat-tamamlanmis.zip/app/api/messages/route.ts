import { and, desc, eq, or, sql } from 'drizzle-orm'
import { auth } from '@/lib/auth'
import { contacts, db, ensureTables, messages, profiles } from '@/lib/messages'

const reply = (data: unknown, status = 200) =>
  Response.json(data, { status, headers: { 'Cache-Control': 'private, no-store' } })

export async function GET() {
  const id = (await auth.getSession()).data?.user?.id
  if (!id) return reply({ error: 'Oturum açmalısın.' }, 401)
  await ensureTables()

  const counterpart = sql<string>`case when ${messages.userId}=${id} then ${messages.recipientId} else ${messages.userId} end`

  const rows = await db
    .select({
      id: messages.id,
      body: messages.body,
      time: messages.createdAt,
      mine: sql<boolean>`${messages.userId}=${id}`,
      peerId: counterpart,
      nickname: profiles.nickname,
    })
    .from(messages)
    .innerJoin(profiles, eq(profiles.userId, counterpart))
    .where(or(eq(messages.userId, id), eq(messages.recipientId, id)))
    .orderBy(desc(messages.createdAt))
    .limit(200)

  return reply(rows.reverse())
}

export async function POST(req: Request) {
  if (!req.headers.get('content-type')?.startsWith('application/json'))
    return reply({ error: 'Geçersiz istek.' }, 415)
  const id = (await auth.getSession()).data?.user?.id
  if (!id) return reply({ error: 'Oturum açmalısın.' }, 401)

  const input = await req.json().catch(() => null)
  const rawNick = typeof input?.nickname === 'string' ? input.nickname.trim() : ''
  const cleaned = rawNick.startsWith('@') ? rawNick.slice(1) : rawNick
  const body = typeof input?.body === 'string' ? input.body.trim() : ''

  if (!cleaned || !body || body.length > 4000) {
    return reply({ error: 'Alıcı takma adını ve mesajını kontrol et.' }, 400)
  }

  await ensureTables()

  const [peer] = await db
    .select({ userId: profiles.userId })
    .from(profiles)
    .where(and(sql`lower(${profiles.nickname}) = lower(${cleaned})`, sql`${profiles.userId} <> ${id}`))
    .limit(1)

  if (!peer) {
    return reply({ error: 'Bu takma ada sahip kullanıcı bulunamadı.' }, 404)
  }

  await db.insert(messages).values({ userId: id, recipientId: peer.userId, body })

  // Ensure peer is in sender's contacts
  await db
    .insert(contacts)
    .values({ userId: id, contactUserId: peer.userId })
    .onConflictDoNothing()

  return reply({ ok: true }, 201)
}
