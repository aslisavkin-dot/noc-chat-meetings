'use client'
import { useState } from 'react'
import useSWR from 'swr'
import { client, googleLogin } from '@/lib/auth-client'
import {
  Phone,
  Video,
  Users,
  Send,
  UserPlus,
  AtSign,
  Check,
  Plus,
  Copy,
  ExternalLink,
  LogOut,
  MessageSquare,
  Sparkles,
} from 'lucide-react'
import './room.css'

type Message = {
  id: string
  body: string
  peerId: string
  nickname: string
  time: string
  mine: boolean
}

type Contact = {
  userId: string
  nickname: string
  fullName: string | null
}

type Meeting = {
  id: string
  roomCode: string
  title: string
  hostId: string
  hostNickname: string | null
  createdAt: string
}

const roomPattern = /^NOC-(Ses|Video|Toplanti)-[0-9a-f-]{36}$/

const fetcher = async (u: string) => {
  const r = await fetch(u)
  if (!r.ok) throw Error(r.status === 401 ? 'Oturumun sona erdi.' : 'Veriler alınamadı.')
  return r.json()
}

export function ChatRoom({
  accountName,
  initialNickname,
}: {
  accountName: string
  initialNickname: string | null
}) {
  const [nickname, setNickname] = useState<string | null>(initialNickname)
  const [nickInput, setNickInput] = useState(
    accountName
      .toLowerCase()
      .replace(/[^a-z0-9_çğıöşü]/g, '')
      .slice(0, 16) || ''
  )
  const [nickError, setNickError] = useState('')
  const [nickSaving, setNickSaving] = useState(false)

  const [tab, setTab] = useState<'sohbet' | 'toplanti'>('sohbet')
  const [addNick, setAddNick] = useState('')
  const [selectedNick, setSelectedNick] = useState('')
  const [body, setBody] = useState('')
  const [room, setRoom] = useState<{ code: string; label: string } | null>(null)
  const [notice, setNotice] = useState('')
  const [busy, setBusy] = useState(false)

  const [meetingTitle, setMeetingTitle] = useState('')
  const [joinCode, setJoinCode] = useState('')

  const { data: contacts = [], mutate: mutateContacts } = useSWR<Contact[]>(
    nickname ? '/api/contacts' : null,
    fetcher,
    { refreshInterval: 5000 }
  )

  const {
    data: messages = [],
    error: msgError,
    mutate: mutateMessages,
  } = useSWR<Message[]>(nickname ? '/api/messages' : null, fetcher, {
    refreshInterval: 3500,
  })

  const { data: meetings = [], mutate: mutateMeetings } = useSWR<Meeting[]>(
    nickname ? '/api/meetings' : null,
    fetcher,
    { refreshInterval: 6000 }
  )

  async function saveNickname(e: React.FormEvent) {
    e.preventDefault()
    setNickSaving(true)
    setNickError('')
    try {
      const r = await fetch('/api/profile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ nickname: nickInput }),
      })
      const res = await r.json()
      if (!r.ok) throw Error(res.error || 'Takma ad kaydedilemedi.')
      setNickname(res.nickname)
    } catch (err) {
      setNickError(err instanceof Error ? err.message : 'Takma ad kaydedilemedi.')
    } finally {
      setNickSaving(false)
    }
  }

  async function handleAddContact(e: React.FormEvent) {
    e.preventDefault()
    const clean = addNick.trim().replace(/^@/, '')
    if (!clean) return
    setBusy(true)
    setNotice('')
    try {
      const r = await fetch('/api/contacts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ nickname: clean }),
      })
      const res = await r.json()
      if (!r.ok) throw Error(res.error || 'Kişi eklenemedi.')
      await mutateContacts()
      setSelectedNick(res.contact.nickname)
      setAddNick('')
      setTab('sohbet')
      setNotice(`@${res.contact.nickname} kişi listene eklendi.`)
    } catch (err) {
      setNotice(err instanceof Error ? err.message : 'Kişi eklenemedi.')
    } finally {
      setBusy(false)
    }
  }

  async function sendMessage(text: string) {
    if (!selectedNick) return false
    setBusy(true)
    setNotice('')
    try {
      const r = await fetch('/api/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ nickname: selectedNick, body: text }),
      })
      const res = await r.json()
      if (!r.ok) throw Error(res.error || 'Mesaj gönderilemedi.')
      await Promise.all([mutateMessages(), mutateContacts()])
      return true
    } catch (err) {
      setNotice(err instanceof Error ? err.message : 'Mesaj gönderilemedi.')
      return false
    } finally {
      setBusy(false)
    }
  }

  async function startCall(type: 'Ses' | 'Video' | 'Toplanti') {
    if (!selectedNick) {
      setNotice('Arama başlatmak için önce listeden bir kişi seç veya takma adıyla ekle.')
      return
    }
    const code = `NOC-${type}-${crypto.randomUUID()}`
    const labelMap = {
      Ses: `@${selectedNick} ile Sesli Arama`,
      Video: `@${selectedNick} ile Görüntülü Arama`,
      Toplanti: `@${selectedNick} ile Toplantı`,
    }
    if (await sendMessage(code)) {
      setRoom({ code, label: labelMap[type] })
    }
  }

  async function createMeeting(e: React.FormEvent) {
    e.preventDefault()
    if (!meetingTitle.trim()) return
    setBusy(true)
    setNotice('')
    try {
      const r = await fetch('/api/meetings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title: meetingTitle.trim() }),
      })
      const res = await r.json()
      if (!r.ok) throw Error(res.error || 'Toplantı oluşturulamadı.')
      await mutateMeetings()
      setMeetingTitle('')
      setRoom({ code: res.meeting.roomCode, label: res.meeting.title })
    } catch (err) {
      setNotice(err instanceof Error ? err.message : 'Toplantı oluşturulamadı.')
    } finally {
      setBusy(false)
    }
  }

  function handleJoinCode(e: React.FormEvent) {
    e.preventDefault()
    const raw = joinCode.trim()
    if (!raw) return
    const extracted = raw.includes('meet.jit.si/')
      ? raw.split('meet.jit.si/')[1].split(/[?#]/)[0]
      : raw
    if (!extracted) return
    setRoom({ code: extracted, label: `Toplantı Odası (${extracted})` })
    setJoinCode('')
  }

  async function signOut() {
    const result = await client.signOut()
    if (!result.error) location.assign('/')
    else setNotice('Çıkış yapılamadı.')
  }

  // EKRAN 1: Girişten hemen sonraki takma ad belirleme ekranı
  if (!nickname) {
    return (
      <div className="scene">
        <div className="shell">
          <header>
            <a className="brand" href="/">
              <img src="/noc.svg" alt="" />
              NOC <span>Chat</span>
            </a>
            <button className="help" onClick={signOut}>
              <LogOut size={15} /> Çıkış yap
            </button>
          </header>

          <main className="nickSetupWrap">
            <section className="glass nickCard">
              <div className="pill">
                <i /> HOŞ GELDİN, {accountName.toUpperCase()}
              </div>
              <h2>Sunucu Takma Adını Belirle</h2>
              <p>
                Diğer kullanıcılar seni takma adınla bulup kişi listesine ekleyebilir;
                seninle sohbet edebilir, sesli veya görüntülü görüşme başlatabilir.
              </p>

              <form onSubmit={saveNickname} className="nickForm">
                <label htmlFor="nicknameInput">Takma adın</label>
                <div className="nickInputBox">
                  <AtSign size={18} />
                  <input
                    id="nicknameInput"
                    type="text"
                    value={nickInput}
                    onChange={(e) => setNickInput(e.target.value)}
                    placeholder="ornek_kullanici"
                    minLength={3}
                    maxLength={24}
                    required
                    autoFocus
                  />
                </div>
                <small className="nickHint">
                  3–24 karakter; harf, rakam ve alt çizgi (_) kullanabilirsin.
                </small>

                {nickError && (
                  <p role="alert" className="nickError">
                    {nickError}
                  </p>
                )}

                <button type="submit" className="google nickSubmit" disabled={nickSaving}>
                  <Check size={18} />
                  {nickSaving ? 'Kaydediliyor...' : 'Takma adımı kaydet ve sunucuya gir'}
                </button>
              </form>
            </section>
          </main>
        </div>
      </div>
    )
  }

  const activeContact = contacts.find(
    (c) => c.nickname.toLowerCase() === selectedNick.toLowerCase()
  )
  const activeMessages = messages.filter(
    (m) => m.nickname.toLowerCase() === selectedNick.toLowerCase()
  )

  return (
    <div className="scene">
      <div className="shell">
        <header>
          <a className="brand" href="/">
            <img src="/noc.svg" alt="" />
            NOC <span>Chat</span>
          </a>
          <div className="headerRight">
            <span className="userBadge" title="Senin takma adın">
              <AtSign size={14} />
              {nickname}
            </span>
            <button className="help" onClick={signOut}>
              <LogOut size={15} /> Çıkış yap
            </button>
          </div>
        </header>

        <main className="workspace">
          {/* SOL PANEL: Takma Ad ile Kişi Ekleme ve Kişi Listesi */}
          <aside className="glass contacts">
            <div className="modeTabs">
              <button
                type="button"
                className={tab === 'sohbet' ? 'tabBtn active' : 'tabBtn'}
                onClick={() => setTab('sohbet')}
              >
                <MessageSquare size={15} /> Kişiler & Sohbet
              </button>
              <button
                type="button"
                className={tab === 'toplanti' ? 'tabBtn active' : 'tabBtn'}
                onClick={() => setTab('toplanti')}
              >
                <Users size={15} /> Toplantılar
              </button>
            </div>

            <form onSubmit={handleAddContact} className="addContactForm">
              <label htmlFor="addNickInput">Takma ad ile kişi ekle</label>
              <div className="addInputRow">
                <input
                  id="addNickInput"
                  type="text"
                  value={addNick}
                  onChange={(e) => setAddNick(e.target.value)}
                  placeholder="@takma_ad"
                />
                <button
                  type="submit"
                  className="help iconOnly"
                  disabled={!addNick.trim() || busy}
                  title="Kişi ekle"
                  aria-label="Kişi ekle"
                >
                  <UserPlus size={16} />
                </button>
              </div>
            </form>

            <div className="contactList">
              <span className="listLabel">Kişilerin ({contacts.length})</span>
              {contacts.length === 0 && (
                <p className="emptyHint">
                  Henüz kimseyi eklemedin. Sunucuya giren birinin takma adını yukarıya yazıp
                  ekleyebilirsin.
                </p>
              )}
              {contacts.map((c) => {
                const isSelected =
                  c.nickname.toLowerCase() === selectedNick.toLowerCase()
                return (
                  <button
                    type="button"
                    key={c.userId}
                    className={isSelected ? 'contactItem selected' : 'contactItem'}
                    onClick={() => {
                      setSelectedNick(c.nickname)
                      setTab('sohbet')
                      setNotice('')
                    }}
                  >
                    <div className="avatar">{c.nickname.slice(0, 2).toUpperCase()}</div>
                    <div className="contactMeta">
                      <strong>@{c.nickname}</strong>
                      {c.fullName && <small>{c.fullName}</small>}
                    </div>
                  </button>
                )
              })}
            </div>
          </aside>

          {/* SAĞ PANEL: Sohbet + Sesli/Görüntülü Arama veya Toplantı Odası */}
          {tab === 'sohbet' ? (
            <section className="glass conversation">
              <div className="convHeader">
                <div>
                  <h2>{activeContact ? `@${activeContact.nickname}` : 'Sohbet seç'}</h2>
                  {activeContact?.fullName && (
                    <small className="subName">{activeContact.fullName}</small>
                  )}
                </div>

                {activeContact && (
                  <div className="actions">
                    <button
                      type="button"
                      className="help callBtn"
                      disabled={busy}
                      onClick={() => startCall('Ses')}
                    >
                      <Phone size={15} /> Sesli ara
                    </button>
                    <button
                      type="button"
                      className="help callBtn video"
                      disabled={busy}
                      onClick={() => startCall('Video')}
                    >
                      <Video size={15} /> Görüntülü ara
                    </button>
                    <button
                      type="button"
                      className="help callBtn meet"
                      disabled={busy}
                      onClick={() => startCall('Toplanti')}
                    >
                      <Users size={15} /> Toplantı
                    </button>
                  </div>
                )}
              </div>

              <div className="history">
                {!activeContact ? (
                  <div className="emptyCenter">
                    <Sparkles size={26} />
                    <p>
                      Sol taraftan eklediğin bir kişiyi seç veya takma adını yazarak yeni birini
                      ekle. Ardından mesajlaşabilir, sesli ya da görüntülü arayabilirsin.
                    </p>
                  </div>
                ) : activeMessages.length === 0 ? (
                  <p>@{activeContact.nickname} kullanıcısına ilk mesajını gönder.</p>
                ) : (
                  activeMessages.map((m) => (
                    <div className={'bubble ' + (m.mine ? 'mine' : '')} key={m.id}>
                      {roomPattern.test(m.body) ? (
                        <button
                          type="button"
                          className="joinCallBtn"
                          onClick={() =>
                            setRoom({
                              code: m.body,
                              label: m.body.startsWith('NOC-Ses')
                                ? `@${m.nickname} ile Sesli Arama`
                                : m.body.startsWith('NOC-Video')
                                  ? `@${m.nickname} ile Görüntülü Arama`
                                  : `@${m.nickname} ile Toplantı`,
                            })
                          }
                        >
                          {m.body.startsWith('NOC-Ses') ? (
                            <Phone size={15} />
                          ) : m.body.startsWith('NOC-Video') ? (
                            <Video size={15} />
                          ) : (
                            <Users size={15} />
                          )}
                          <span>
                            {m.body.startsWith('NOC-Ses')
                              ? 'Sesli aramaya katıl →'
                              : m.body.startsWith('NOC-Video')
                                ? 'Görüntülü aramaya katıl →'
                                : 'Toplantıya katıl →'}
                          </span>
                        </button>
                      ) : (
                        m.body
                      )}
                      <small>
                        {new Date(m.time).toLocaleTimeString('tr', {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </small>
                    </div>
                  ))
                )}
              </div>

              {msgError && (
                <p role="alert">
                  {msgError.message}{' '}
                  <button type="button" onClick={() => mutateMessages()}>
                    Tekrar dene
                  </button>{' '}
                  ·{' '}
                  <button
                    type="button"
                    onClick={() =>
                      googleLogin().catch(() => setNotice('Google bağlantısı kurulamadı.'))
                    }
                  >
                    Google ile giriş
                  </button>
                </p>
              )}

              {notice && <p role="status" className="noticeBar">{notice}</p>}

              <form
                onSubmit={async (e) => {
                  e.preventDefault()
                  if (await sendMessage(body)) setBody('')
                }}
              >
                <input
                  aria-label="Mesaj"
                  placeholder={
                    activeContact
                      ? `@${activeContact.nickname} kişisine mesaj yaz…`
                      : 'Önce bir kişi seç…'
                  }
                  value={body}
                  maxLength={4000}
                  disabled={!activeContact}
                  required
                  onChange={(e) => setBody(e.target.value)}
                />
                <button
                  type="submit"
                  className="help"
                  disabled={!activeContact || !body.trim() || busy}
                  aria-label="Gönder"
                >
                  <Send size={18} />
                </button>
              </form>
            </section>
          ) : (
            <section className="glass conversation">
              <div className="convHeader">
                <div>
                  <h2>Toplantı Odaları</h2>
                  <small className="subName">
                    Çoklu katılımcılı toplantı başlat veya mevcut bir odaya katıl
                  </small>
                </div>
              </div>

              <div className="meetingFormsGrid">
                <form onSubmit={createMeeting} className="meetBox">
                  <label htmlFor="meetTitle">Yeni toplantı başlat</label>
                  <div className="addInputRow">
                    <input
                      id="meetTitle"
                      type="text"
                      placeholder="Örn: Haftalık Ekip Toplantısı"
                      value={meetingTitle}
                      maxLength={80}
                      onChange={(e) => setMeetingTitle(e.target.value)}
                    />
                    <button
                      type="submit"
                      className="help"
                      disabled={!meetingTitle.trim() || busy}
                    >
                      <Plus size={16} /> Başlat
                    </button>
                  </div>
                </form>

                <form onSubmit={handleJoinCode} className="meetBox">
                  <label htmlFor="joinCodeInput">Oda kodu veya bağlantısı ile katıl</label>
                  <div className="addInputRow">
                    <input
                      id="joinCodeInput"
                      type="text"
                      placeholder="NOC-Toplanti-... veya link"
                      value={joinCode}
                      onChange={(e) => setJoinCode(e.target.value)}
                    />
                    <button type="submit" className="help" disabled={!joinCode.trim()}>
                      Katıl
                    </button>
                  </div>
                </form>
              </div>

              {notice && <p role="status" className="noticeBar">{notice}</p>}

              <div className="history">
                <span className="listLabel">Aktif Sunucu Toplantıları</span>
                {meetings.length === 0 ? (
                  <p>Şu an aktif toplantı odası yok. Yukarıdan yeni bir toplantı başlatabilirsin.</p>
                ) : (
                  meetings.map((m) => (
                    <div key={m.id} className="meetingCard">
                      <div>
                        <strong>{m.title}</strong>
                        <small>
                          Oluşturan: @{m.hostNickname || 'kullanici'} ·{' '}
                          {new Date(m.createdAt).toLocaleTimeString('tr', {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </small>
                      </div>
                      <button
                        type="button"
                        className="help callBtn meet"
                        onClick={() => setRoom({ code: m.roomCode, label: m.title })}
                      >
                        <Users size={15} /> Katıl
                      </button>
                    </div>
                  ))
                )}
              </div>
            </section>
          )}
        </main>

        {/* AKTİF SESLİ / GÖRÜNTÜLÜ ARAMA VEYA TOPLANTI EKRANI */}
        {room && (
          <section className="glass meeting">
            <div className="convHeader">
              <div>
                <h2>{room.label}</h2>
                <small className="subName">Oda kodu: {room.code}</small>
              </div>
              <div className="actions">
                <button
                  type="button"
                  className="help"
                  onClick={() =>
                    navigator.clipboard
                      .writeText('https://meet.jit.si/' + room.code)
                      .then(() => setNotice('Toplantı / arama bağlantısı kopyalandı.'))
                      .catch(() => setNotice('Bağlantı kopyalanamadı.'))
                  }
                >
                  <Copy size={15} /> Daveti kopyala
                </button>
                <a
                  className="help"
                  target="_blank"
                  rel="noreferrer"
                  href={'https://meet.jit.si/' + room.code}
                >
                  <ExternalLink size={15} /> Ayrı sekmede aç
                </a>
                <button
                  type="button"
                  className="help leaveBtn"
                  onClick={() => setRoom(null)}
                >
                  Ayrıl
                </button>
              </div>
            </div>
            <iframe
              title="NOC görüşmesi"
              allow="microphone; camera; fullscreen; display-capture; autoplay"
              src={
                'https://meet.jit.si/' +
                room.code +
                '#userInfo.displayName="' +
                encodeURIComponent('@' + nickname) +
                '"&config.prejoinPageEnabled=false&config.startWithVideoMuted=' +
                room.code.startsWith('NOC-Ses')
              }
            />
          </section>
        )}
      </div>
    </div>
  )
}
